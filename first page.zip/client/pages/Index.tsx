export default function Index() {
  return (
    <div className="min-h-screen bg-brand-background flex items-center justify-center p-6">
      {/* Android phone frame */}
      <div className="relative w-[340px] sm:w-[380px] md:w-[420px] aspect-[9/19.5] rounded-[2.5rem] bg-black/80 shadow-2xl ring-1 ring-black/30 p-2">
        {/* Side buttons */}
        <div className="absolute -left-1 top-24 h-16 w-1 rounded-full bg-black/50" />
        <div className="absolute -right-1 top-20 h-10 w-1 rounded-full bg-black/50" />
        <div className="absolute -right-1 top-36 h-10 w-1 rounded-full bg-black/50" />

        {/* Screen */}
        <div className="w-full h-full rounded-[2.2rem] bg-brand-background overflow-hidden relative flex flex-col items-center justify-center">
          {/* Camera/earpiece area */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 mt-2 w-24 h-6 bg-black/70 rounded-b-2xl" />

          {/* Content */}
          <div className="text-center px-6">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/ada46f89a92087dea35b270d6a10fba065e7b5f9?width=820"
              alt="BOLDSHE Shield Logo"
              className="w-48 h-48 md:w-56 md:h-56 mx-auto object-contain mb-6"
            />
            {/* Keep a single brand mark: remove duplicate text logo */}
            <p className="text-black text-base md:text-lg font-semibold italic">
              safety and empowerment platform
            </p>
          </div>

          {/* Android nav bar */}
          <div className="absolute bottom-4 left-0 right-0 flex items-center justify-center gap-6 text-black/70">
            <div className="h-1.5 w-8 rounded-full bg-black/40" />
          </div>
        </div>
      </div>
    </div>
  );
}
